<?php $__env->startSection('main_content'); ?>
<div class="row">
  <div class="col-md-12">
    <h1><?php echo e($product['title']); ?></h1>
    <p><img width="500" src="<?php echo e(asset('images/'.$product['image'])); ?>"></p>
    <p><?php echo $product['article']; ?></p>
    <p><b>Price on site:</b><?php echo e($product['price']); ?>$</p>
     <input data-id="<?php echo e($product['id']); ?>" class="btn btn-success add-to-cart-btn" type="button" value="+Add to cart">
     <a class='btn btn-primary' href='<?php echo e(url('shop/checkout')); ?>'>Checkout</a>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>