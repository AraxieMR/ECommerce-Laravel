<?php $__env->startSection('main_content'); ?>
<div class="row">
  <div class="col-md-12">
    <h1>iCar Checkout page</h1>
  </div>
</div>
<div class='row'>
  <div class='col-md-12'>   
    <?php if($cart): ?>
    <table class='table table-bordered'>
      <thead>
        <tr>
          <th>Product</th>
          <th>Quantity</th>
          <th>Price</th>
          <th>Sub Total</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($item['name']); ?></td>
            <td>
              <input data-id="<?php echo e($item['id']); ?>" type="button" value="-" class="update-cart">
              <input class="text-center" type="text" size="1"value="<?php echo e($item['quantity']); ?>">
              <input data-id="<?php echo e($item['id']); ?>" type="button" value="+" class="update-cart">
            </td>
            <td><?php echo e($item['price']); ?>$</td>
                        
            <td><?php echo e($item['quantity'] * $item['price']); ?> $</td>
            <td class="text-center">
             <a href='<?php echo e(url('shop/remove-item'.$item['id'])); ?>'>
              <span style="color:red" class="glyphicon glyphicon-trash " aria-hidden="true"></span>
             </a>
            </td>  
          </tr> 
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       
      </tbody>
    </table>
    <p><b>Total in cart:</b><?php echo e(Cart::getTotal()); ?>$
      <span><a  class="btn btn-default pull-right" href="<?php echo e(url('shop/clear-cart')); ?>">Clear Cart</a></span>
    </p>
    <p>
      <a  class="btn btn-primary" href="<?php echo e(url('shop/order')); ?>">Order Now</a>
    </p>
    <?php else: ?>                            
    <p><i>No items in cart</i></p>
    <?php endif; ?>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>