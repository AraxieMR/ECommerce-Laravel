<?php $__env->startSection('cms_content'); ?>
<h3 class="page-header">Are you sure you want to delete this menu ?</h3>

<br><br>
<div class="row">
  <div class="col-md-6">
    <form  action='<?php echo e(url('cms/menu/'.$id)); ?>' method="POST">
      <?php echo e(csrf_field()); ?>

      <?php echo e(method_field('DELETE')); ?>

     
      <div class="form-group">
       
      <a href= "<?php echo e(url('cms/menu')); ?>" class="btn btn-default">Cancel</a>
      <input class='btn btn-danger' type='submit' name='submit' value='Delete'>
    </form>

  </div>
  
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('cms.cms_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>