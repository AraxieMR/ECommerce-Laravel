<?php $__env->startSection('cms_content'); ?>
<h1 class="page-header">Edit content</h1>

<br><br>
<div class="row">
  <div class="col-md-6">
    <form  action= "<?php echo e(url('cms/content/'.$content['id'])); ?>" method="POST">
      <?php echo e(csrf_field()); ?>

      <?php echo e(method_field('PUT')); ?>

      <div class="form-group">
        <label for="menu-link"></label>
        <select id="menu-link" name="menu_id" class="form-control">
       
          <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option <?php if(  $content['menu_id'] ): ?> == $item['id'] )  selected="selected" <?php endif; ?> value="<?php echo e($item['id']); ?>"><?php echo e($item['link']); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
       </div>
      <div class="form-group">
        <label for="title">Title</label>
        <input name="title" value="<?php echo e($content['title']); ?>" type="text" class="form-control" id="title"  placeholder="title">
        <!--<span class="text-danger"><?php echo e($errors->first('email')); ?></span>-->
      </div>
        <div class="form-group">
        <label for="article">Article</label>
        <textarea id="article" name='article' class="form-control"> <?php echo e($content['article']); ?> </textarea>
        <!--<span class="text-danger"><?php echo e($errors->first('email')); ?></span>-->
      </div>
          <br><br>
      <a href= "<?php echo e(url('cms/content')); ?>" class="btn btn-default">Cancel</a>
      <input class="btn btn-primary" type="submit" name="submit" value="Update">
    </form>

  </div>
  
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('cms.cms_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>