<?php $__env->startSection('main_content'); ?>
<div class="row">
  <div class="col-md-12">
    <h1>Please sign in with your account</h1>
  </div>
</div>
<div class='row'>
  <div class='col-md-6'>
    <form class='form-group' action='' method="POST">
      <?php echo e(csrf_field()); ?>

     <div class="form-group">
      <label for="email">Email</label>
      <input name='email' value='<?php echo e(old('email')); ?>' type="text" class="form-control" id="email"  placeholder="Enter email">
      <!--<span class="text-danger"><?php echo e($errors->first('email')); ?></span>-->
     </div>
      
      <div class="form-group">
      <label for="password">Password</label>
      <input name='password' type="password" class="form-control" id="password"  placeholder="Enter password">
      <!--<span class="text-danger"><?php echo e($errors->first('password')); ?></span>-->
     </div>
      <input class='btn btn-primary' type='submit' name='submit' value='Sign In'>
    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>