<?php $__env->startSection('cms_content'); ?>
<h1 class="page-header">Edit new item</h1>

<br><br>
<div class="row">
  <div class="col-md-6">
    <form  action='<?php echo e(url('cms/menu/'.$menu['id'])); ?>' method="POST">
      <?php echo e(csrf_field()); ?>

      <?php echo e(method_field('PUT')); ?>

      <input type="hidden" name="item_id" value=" <?php echo e($menu['id']); ?>">
      <div class="form-group">
        <label for="link">Link</label>
        <input name='link' value="<?php echo e($menu['link']); ?>" type="text" class="form-control origin-text" id="link"  placeholder="link">
        <!--<span class="text-danger"><?php echo e($errors->first('email')); ?></span>-->
      </div>
      <div class="form-group">
        <label for="title">Title</label>
        <input name='mtitle' value="<?php echo e($menu['mtitle']); ?>" type="text" class="form-control" id="title"  placeholder="title">
        <!--<span class="text-danger"><?php echo e($errors->first('email')); ?></span>-->
      </div>
       <label for="url">Url</label>
        <input name='url' value="<?php echo e($menu['url']); ?>" type="text" class="form-control target-text" id="url"  placeholder="url">
        <!--<span class="text-danger"><?php echo e($errors->first('email')); ?></span>-->
          <br><br>
      <a href= "<?php echo e(url('cms/menu')); ?>" class="btn btn-default">Cancel</a>
      <input class='btn btn-primary' type='submit' name='submit' value='Update'>
    </form>

  </div>
  
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('cms.cms_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>