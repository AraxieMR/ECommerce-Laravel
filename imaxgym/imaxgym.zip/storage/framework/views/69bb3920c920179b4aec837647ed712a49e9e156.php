﻿<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title><?php echo e($title); ?> </title>
    <link rel="icon" href="images/favicon-4.png" type="image/png">
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Open+Sans:400,400italic,600,600italic,700,700italic,800,800italic,300,300italic">

    <!-- Begin: MAIN CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('lib/iMax/assets/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('lib/iMax/assets/css/style.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('lib/iMax/assets/css/plugins-min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('lib/iMax/assets/css/menu-overright.css')); ?>">
    <link href="<?php echo e(asset('lib/iMax/assets/css/colors/orange-burgundy.css')); ?>" type="text/css" media="all" rel="stylesheet" id="colors" />
    <!-- End: MAIN CSS -->

    <!-- Begin: REQUIRED FOR THIS PAGE ONLY -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('lib/iMax/assets/plugins/revolution/css/layers.css')); ?>"/> 
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('lib/iMax/assets/plugins/revolution/css/settings.css')); ?>"/> 
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('lib/iMax/assets/plugins/revolution/css/navigation.css')); ?>"/> 
    <script>var BASE_URL = "<?php echo e(url('')); ?>/";</script>
    <!-- End: REQUIRED FOR THIS PAGE ONLY -->

    <!-- Begin: HTML5SHIV FOR IE8 -->
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="js/internetexplorer/html5shiv.min.js"></script>
      <script src="js/internetexplorer/respond.min.js"></script>
    <![endif]-->
    <!-- end: HTML5SHIV FOR IE8 -->
    <style>
        h1, h2, h3, h4, h5, h6,
        .base-font-family {
            font-family: 'Raleway', sans-serif !important;
        }
    </style>
</head>

<body class="switcher_boxed boxed">

    <!-- Begin: HEADER SEARCH
    <div class="modal fade header-search" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-md" role="document">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <div class="search">
                <form method="get" action="search.html">
                    <div class="form-group full-width">
                        <div class="input-group">
                            <input type="text" class="form-control input-lg" placeholder="Search Here..." value="" name="q">
                            <div class="input-group-btn "><button type="submit" class="btn btn-base btn-lg"><i class="fa fa-search"></i></button></div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
 End: HEADER SEARCH -->

    <!--
    #################################
        - Begin: HEADER -
    #################################
    -->
    <header class="main-header sticky-header logo-position-top-setting logo-position-top base">
        <nav class="navbar navbar-default">
            <div class="container-fluid position-relative">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header dark-bg-setting dark-bg">
                    <!-- Begin: RESPONSIVE MENU TOGGLER -->
                    <button type="button" class="navbar-toggle" data-toggle="modal" data-target=".header-search">
                        <span class="sr-only">Toggle navigation</span>
                        <i class="fa fa-search"></i>
                    </button>
                    <!-- End: RESPONSIVE MENU TOGGLER -->
                    <!-- Begin: RESPONSIVE MENU TOGGLER -->
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#nav-navbar-collapse-2">
                        <span class="sr-only">Toggle navigation</span>
                        <i class="fa fa-shopping-bag"></i>
                    </button>
                    <!-- End: RESPONSIVE MENU TOGGLER -->
                    <!-- Begin: RESPONSIVE MENU TOGGLER -->
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#nav-navbar-collapse-1">
                        <span class="sr-only">Toggle navigation</span>
                        <i class="fa fa-bars"></i>
                    </button>
                    <!-- End: RESPONSIVE MENU TOGGLER -->
                    <!-- Begin: LOGO -->
                    <a class="navbar-brand logo" href="<?php echo e(url('')); ?>"><span><i class="fa fa-info"></i></span> MaxGym</a>
                    <!-- End: LOGO -->
                </div>
                <div class="logo-position-top-menu">
                    <div class="collapse navbar-collapse text-weight-400" id="nav-navbar-collapse-1">
                        <ul class="nav navbar-nav navbar-right margin-right-0">
                          <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="dropdown">
                                <a href="<?php echo e(url($item['url'])); ?>" class="dropdown-toggle" data-toggle="" data-hover="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php echo e($item['link']); ?> <span class="caret"></span></a>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </li>   
                         <!--     <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" role="button" aria-haspopup="true" aria-expanded="false">About <span class="caret"></span></a>
                             </li>   -->
                           <li class="dropdown">
                                <a href="<?php echo e(url('shop')); ?>" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Shop <span class="caret"></span></a>
                            </li>  
                              <?php if( !Session::has('user_id') ): ?>
                                  <li>
                                     <a href="<?php echo e(url('user/signin')); ?>" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" role="button" aria-haspopup="true" aria-expanded="false">SignIn <span class="caret"></span></a>
                                  </li>
                                   <li>
                                     <a href="<?php echo e(url('user/signup')); ?>" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" role="button" aria-haspopup="true" aria-expanded="false">SignUp <span class="caret"></span></a>
                                  </li>
                                <?php else: ?>
                             <li><a href="<?php echo e(url('user/profile')); ?>" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php echo e(Session::get('user_name')); ?></a></li>
                             
               <?php if( Session::has('is_admin') ): ?>
                <li><a href="<?php echo e(url('cms/dashboard')); ?>" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" role="button" aria-haspopup="true" aria-expanded="false">CMS Dashboard</a></li>
               <?php endif; ?>
              <li><a href="<?php echo e(url('user/logout')); ?>" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Logout</a></li>
              <?php endif; ?>
                 <div class="collapse navbar-collapse pull-right search-shop-dropdown" id="nav-navbar-collapse-2">
                    <ul class="nav navbar-nav navbar-right margin-right-0">
                        <li class="dropdown search-dropdown hidden-xs hidden-sm"> <a href="#" class="" data-toggle="modal" data-target=".header-search"><i class="fa fa-search"></i></a> </li>
                        <li class="dropdown shop-cart-dropdown">
                            <a href="<?php echo e(url('shop/checkout')); ?>" class="dropdown-toggle hidden-xs hidden-sm" data-hover="dropdown" data-toggle="" role="button" aria-haspopup="true" aria-expanded="false"> <i class="fa fa-shopping-bag"></i>
                               <?php if( !Cart::isEmpty() ): ?>
                              <span class="badge"><?php echo e(Cart::getTotalQuantity()); ?></span> </a>
                                 <?php endif; ?>
                            <!--<ul class="dropdown-menu">
                                <li class="list-img">
                                    <ul class="list-ul">
                                        <li>
                                            <div class="row text-weight-700">
                                                <div class="col-xs-8">item(s)</div>
                                                <div class="col-xs-4 text-right">$90</div>
                                            </div>
                                        </li>
                                        <li class="alert">
                                            <div class="close"><a href="#" data-dismiss="alert" aria-hidden="false"><i class="fa fa-close"></i></a></div>
                                            <div class="list-img"> <a href="#"><img src="images/widgets/shop-1.jpg" alt=""></a> </div>
                                            <div class="list-text">
                                                <h5 class="list-title text-weight-600"><a href="#">Halter Neck Dress</a></h5>
                                                <ul class="list-meta list-inline">
                                                    <li><i class="fa fa-usd"></i> 30.00</li>
                                                    <li>
                                                        <div class="star-rating" data-toggle="tooltip" data-placement="top" title="5.00"> <span class="width-100"><strong class="rating">5.00</strong> out of 5</span> </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </li>
                                        <li class="alert">
                                            <div class="close"><a href="#" data-dismiss="alert" aria-hidden="false"><i class="fa fa-close"></i></a></div>
                                            <div class="list-img"> <a href="#"><img src="images/widgets/shop-2.jpg" alt=""></a> </div>
                                            <div class="list-text">
                                                <h5 class="list-title text-weight-600"><a href="#">Maxi Sweater Dress</a></h5>
                                                <ul class="list-meta list-inline">
                                                    <li><i class="fa fa-usd"></i> 30.00</li>
                                                    <li>
                                                        <div class="star-rating" data-toggle="tooltip" data-placement="top" title="4.00"> <span class="width-80"><strong class="rating">4.00</strong> out of 5</span> </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </li>
                                        <li class="alert">
                                            <div class="close"><a href="#" data-dismiss="alert" aria-hidden="false"><i class="fa fa-close"></i></a></div>
                                            <div class="list-img"> <a href="#"><img src="images/widgets/shop-3.jpg" alt=""></a> </div>
                                            <div class="list-text">
                                                <h5 class="list-title text-weight-600"><a href="#">Mixed Fabric Jacket</a></h5>
                                                <ul class="list-meta list-inline">
                                                    <li><i class="fa fa-usd"></i> 30.00</li>
                                                    <li>
                                                        <div class="star-rating" data-toggle="tooltip" data-placement="top" title="2.50"> <span class="width-50"><strong class="rating">2.50</strong> out of 5</span> </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </li>
                                    </ul>
                                </li>
                                <li class="shop-cart-btn">
                                    <div class="btn-group btn-group-justified"> <a href="shop-cart.html" class="btn btn-base btn-sm text-weight-700 text-spacing-2 text-uppercase">View Cart</a> <a href="shop-checkout.html" class="btn btn-dark btn-sm text-weight-700 text-spacing-2 text-uppercase">Checkout</a> </div>
                                </li>
                            </ul>-->
                        </li>
                    </ul>
                </div>
                           </ul>   
                </div>
            </div>
        </nav>
    </header>


  
   <?php echo $__env->yieldContent('main_content'); ?>
    <!--
    #################################
        - Begin: FOOTER -
    #################################
    -->
    <footer id="footer" class="dark-bg">
        <div class="top-footer">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-sm-12">
                        <!-- Begin: WIDGET -->
                        <div class="widget map-bg">
                            <h3 class="widget-title text-weight-700">Contact Us</h3>
                            <address> <abbr title="Address"><strong>Address:</strong></abbr><br> 1355 Market Street, Suite 900<br> San Francisco, CA 94103 </address>
                            <address> <abbr title="Phone"><strong>Phone:</strong></abbr><br> (123) 456-7890 </address>
                            <address> <abbr title="Email"><strong>Email:</strong></abbr><br> <a href="mailto:#">info@imaxGym.com</a> </address>
                        </div>
                        <!-- End: WIDGET -->
                    </div>
                    <div class="col-md-3 col-sm-12">
                        <!-- Begin: WIDGET -->
                        <div class="widget">
                            <div class="list-link">
                                <h3 class="widget-title text-weight-700">Pages</h3>
                                <ul class="list-ul">
                                    <li><i class="fa fa-circle-o"></i><a href="#">Home</a></li>
                                    <li><i class="fa fa-circle-o"></i><a href="#">About</a></li>
                                    <li><i class="fa fa-circle-o"></i><a href="#">Services</a></li>
                                    <li><i class="fa fa-circle-o"></i><a href="#">Blog</a></li>
                                    <li><i class="fa fa-circle-o"></i><a href="#">Contact Us</a></li>
                                </ul>
                            </div>
                        </div>
                        <!-- End: WIDGET -->
                    </div>
                    <div class="col-md-3 col-sm-12">
                        <!-- Begin: WIDGET -->
                        <div class="widget">
                            <div class="list-link">
                                <h3 class="widget-title text-weight-700">Shortcut links</h3>
                                <ul class="list-ul">
                                    <li><i class="fa fa-circle-o"></i><a href="#">ante etiam sit</a></li>
                                    <li><i class="fa fa-circle-o"></i><a href="#">mauris sit</a></li>
                                    <li><i class="fa fa-circle-o"></i><a href="#">Sed consequat</a></li>
                                    <li><i class="fa fa-circle-o"></i><a href="#">idunt duis</a></li>
                                    <li><i class="fa fa-circle-o"></i><a href="#">sit amet orci</a></li>
                                    <li><i class="fa fa-circle-o"></i><a href="#">donec sodales</a></li>
                                </ul>
                            </div>
                        </div>
                        <!-- End: WIDGET -->
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <!-- Begin: WIDGET -->
                        <div class="widget">
                            <div class="list-link">
                                <h3 class="widget-title text-weight-700">We are open</h3>
                                <div class="textwidget">
                                    <p>Mon-Thu: 9:30 - 21:00</p>
                                    <p>Fri: 6:00 - 21:00</p>
                                    <p>Sat: 10:00 - 15:00</p>
                                </div>
                            </div>
                        </div>
                        <!-- End: WIDGET -->
                    </div>
                </div>
            </div>
        </div>
        <div class="bottom-footer">
            <div class="container">
                <div class="row">
                    <div class="col-md-2 col-sm-2"> <a href="<?php echo e(asset('lib/iMax/assets/gym-index.html')); ?>" class="logo"><span><i class="fa fa-info"></i></span> MAXGYM</a> </div>
                    <div class="col-md-10 col-sm-10 text-right">
                        <p>&copy; Copyright 2017 by <a href="#">iMaxGym</a>. All Rights Reserved.</p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- End: FOOTER -
    ################################################################## -->

    <!-- Begin: BACK TO TOP -->
    <a id="back-to-top" href="#" class="back-to-top btn btn-base">
        <i class="fa fa-chevron-up"></i>
    </a>
    <!-- End: BACK TO TOP -->
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script type="text/javascript" src="<?php echo e(asset('lib/iMax/assets/js/jquery.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('lib/iMax/assets/js/bootstrap.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('lib/iMax/assets/js/plugins.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('lib/iMax/assets/js/main.js')); ?>"></script>

    <!-- Begin: REQUIRED FOR THIS PAGE ONLY -->
    <script type="text/javascript" src="<?php echo e(asset('lib/iMax/assets/plugins/revolution/jquery.themepunch.revolution.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('lib/iMax/assets/plugins/revolution/jquery.themepunch.tools.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('lib/iMax/assets/plugins/revolution/extensions/revolution.extension.actions.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('lib/iMax/assets/plugins/revolution/extensions/revolution.extension.carousel.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('lib/iMax/assets/plugins/revolution/extensions/revolution.extension.kenburn.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('lib/iMax/assets/plugins/revolution/extensions/revolution.extension.layeranimation.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('lib/iMax/assets/plugins/revolution/extensions/revolution.extension.migration.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('lib/iMax/assets/plugins/revolution/extensions/revolution.extension.navigation.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('lib/iMax/assets/plugins/revolution/extensions/revolution.extension.parallax.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('lib/iMax/assets/plugins/revolution/extensions/revolution.extension.slideanims.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('lib/iMax/assets/plugins/revolution/extensions/revolution.extension.video.min.js')); ?>"></script>
    <!-- Slider JS -->
    <script type="text/javascript">
    var tpj=jQuery;         
        var revapi4;
        tpj(document).ready(function() {
            if(tpj("#rev_slider").revolution == undefined){
                revslider_showDoubleJqueryError("#rev_slider");
            }else{
                revapi6 = tpj("#rev_slider").show().revolution({
                    sliderType:"standard",
                    jsFileLocation:"<?php echo e(asset('lib/iMax/assets/plugins/revolution/')); ?>",
                    sliderLayout:"fullscreen",
                    dottedOverlay:"none",
                    delay:9000,
                    navigation: {
                        keyboardNavigation:"off",
                        keyboard_direction: "horizontal",
                        mouseScrollNavigation:"off",
                        mouseScrollReverse:"default",
                        onHoverStop:"on",
                        touch:{
                            touchenabled:"on",
                            swipe_threshold: 75,
                            swipe_min_touches: 1,
                            swipe_direction: "horizontal",
                            drag_block_vertical: false
                        }
                        ,
                        arrows: {
                            style:"metis",
                            enable:true,
                            hide_onmobile:true,
                            hide_under:800,
                            hide_onleave:true,
                            hide_delay:200,
                            hide_delay_mobile:1200,
                            tmp:'',
                            left: {
                                h_align:"left",
                                v_align:"center",
                                h_offset:20,
                                v_offset:0
                            },
                            right: {
                                h_align:"right",
                                v_align:"center",
                                h_offset:20,
                                v_offset:0
                            }
                        }
                        ,
                        bullets: {
                            enable:true,
                            hide_onmobile:false,
                            style:"uranus",
                            hide_onleave:false,
                            direction:"horizontal",
                            h_align:"center",
                            v_align:"bottom",
                            h_offset:0,
                            v_offset:20,
                            space:5,
                            tmp:'<span class="tp-bullet-inner"></span>'
                        }
                    },
                    visibilityLevels:[1240,1024,778,480],
                    gridwidth:1240,
                    gridheight:500,
                    lazyType:"none",
                    parallax: {
                        type:"mouse",
                        origo:"enterpoint",
                        speed:400,
                        levels:[5,10,15,20,25,30,35,40,45,46,47,48,49,50,51,55],
                        type:"mouse",
                    },
                    shadow:0,
                    spinner:"spinner2",
                    stopLoop:"off",
                    stopAfterLoops:-1,
                    stopAtSlide:-1,
                    shuffle:"off",
                    autoHeight:"off",
                    fullScreenAutoWidth:"off",
                    fullScreenAlignForce:"off",
                    fullScreenOffsetContainer: "",
                    fullScreenOffset: "",
                    disableProgressBar:"on",
                    hideThumbsOnMobile:"off",
                    hideSliderAtLimit:0,
                    hideCaptionAtLimit:0,
                    hideAllCaptionAtLilmit:0,
                    debugMode:false,
                    fallbacks: {
                        simplifyAll:"off",
                        nextSlideOnWindowFocus:"off",
                        disableFocusListener:false,
                    }
                });
            }
        }); /*ready*/
    </script>
    <script>
        $(document).ready(function () {
            $(".testimonials").owlCarousel({
                autoPlay: 3000,
                stopOnHover: false,
                navigation: true,
                pagination: false,
                paginationSpeed: 1000,
                goToFirstSpeed: 2000,
                singleItem: true,
                autoHeight: true,
                transitionStyle: "fadeUp" // "fade", "fadeUp", "backSlide", "goDown"
            });
        });
    </script>
    <!-- End: REQUIRED FOR THIS PAGE ONLY -->

</body>
</html>