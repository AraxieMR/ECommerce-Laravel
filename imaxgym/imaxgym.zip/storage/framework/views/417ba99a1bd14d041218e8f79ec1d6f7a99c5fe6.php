<?php $__env->startSection('main_content'); ?>
<div class="row">
  <div class="col-md-12">
    <h1>iCar shop categories</h1>
  </div>
</div>
<div class="row">
  <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="col-md-4 col-sm-6">
   
    <h3><?php echo e($category['title']); ?></h3>
    <p><img width="200" src="<?php echo e(asset('images/'.$category['image'])); ?>"></p>
    <p><?php echo $category['article']; ?></p>
 
    <a class="btn btn-success" href="<?php echo e(url('shop/'.$category['url'])); ?>" >View products</a>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>