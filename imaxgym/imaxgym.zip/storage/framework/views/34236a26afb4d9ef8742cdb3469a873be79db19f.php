<?php $__env->startSection('main_content'); ?>
<div class="row">
  <div class="col-md-12">
    <h1><?php echo e(str_replace('iCAR | ','',$title)); ?></h1>
    
  </div>
</div>
<?php if( !empty($products)): ?>
<div class="row">
<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-md-6">
  <h3><?php echo e($product['title']); ?></h3>
  <p><img width="300" src="<?php echo e(asset('images/'.$product['image'])); ?>"></p>
  <p><?php echo $product['article']; ?></p>

  <p>Price on site:<?php echo e($product['price']); ?>$</p>
  <?php if( !Cart::get($product['id'])): ?>
  <input data-id="<?php echo e($product['id']); ?>" class="btn btn-success add-to-cart-btn" type="button" value="+Add to cart">
  <?php else: ?>
  <input  class="btn btn-success " disabled='disabled' type="button" value="In cart">
  <?php endif; ?>       
  <a  class="btn btn-primary" href="<?php echo e(url('shop/'.$cat_url.'/'.$product['url'])); ?>">More details</a>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>