 
 <?php $__env->startSection('cms_content'); ?>
          <h1 class="page-header">Edit site categories</h1>
          <div class='row'>
            <div class='col-md-12'>
              <p>
                <a class="btn btn-primary" href='<?php echo e(url('cms/categories/create')); ?>'>+Add new categorie</a>
              </p>
             
            </div>
          </div>   
          <br><br>
          <div class="row">
            <div class="col-md-8">
               <table class="table table-bordered">
                <thead>
                <th>Title</th>
                   <th>Category image</th>
                 <th>Updated at</th>
                  <th>Operation</th>
                 </thead>
                 <tbody>
                   <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr>
                         <td><?php echo e($item['title']); ?></td>
                         <td><img width='50' src='<?php echo e(asset('images/'.$item['image'])); ?>'></td>
                          <td><?php echo e($item['updated_at']); ?></td>
                          <td>
                            <a href="<?php echo e(url('cms/categories/'.$item['id'].'/edit')); ?>">Edit</a> |
                             <a href="<?php echo e(url('cms/categories/'.$item['id'])); ?>">Delete</a>
                          </td>
                       </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                 </tbody>
              </table>
            </div>
          </div>
          
<?php $__env->stopSection(); ?>


<?php echo $__env->make('cms.cms_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>