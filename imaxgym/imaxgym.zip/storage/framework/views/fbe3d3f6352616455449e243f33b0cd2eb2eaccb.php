<header class="main-header sticky-header logo-position-top-setting logo-position-top base">
  <nav class="navbar navbar-default">
    <div class="container-fluid position-relative">
      <!-- Brand and toggle get grouped for better mobile display -->
      <div class="navbar-header dark-bg-setting dark-bg">
        <!-- Begin: RESPONSIVE MENU TOGGLER -->
        <button type="button" class="navbar-toggle" data-toggle="modal" data-target=".header-search">
          <span class="sr-only">Toggle navigation</span>
          <i class="fa fa-search"></i>
        </button>
        <!-- End: RESPONSIVE MENU TOGGLER -->
        <!-- Begin: RESPONSIVE MENU TOGGLER -->
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#nav-navbar-collapse-2">
          <span class="sr-only">Toggle navigation</span>
          <i class="fa fa-shopping-bag"></i>
        </button>
        <!-- End: RESPONSIVE MENU TOGGLER -->
        <!-- Begin: RESPONSIVE MENU TOGGLER -->
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#nav-navbar-collapse-1">
          <span class="sr-only">Toggle navigation</span>
          <i class="fa fa-bars"></i>
        </button>
        <!-- End: RESPONSIVE MENU TOGGLER -->
        <!-- Begin: LOGO -->
        <a class="navbar-brand logo" href="<?php echo e(url('')); ?>"><span><i class="fa fa-info"></i></span> MaxGym</a>
        <!-- End: LOGO -->
      </div>
      <div class="logo-position-top-menu">
        <div class="collapse navbar-collapse text-weight-400" id="nav-navbar-collapse-1">
          <ul class="nav navbar-nav navbar-right margin-right-0">
            <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li > <a href="<?php echo e(url($item['url'])); ?>" ><?php echo e($item['link']); ?> <span ></span></a> </li> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <li > <a href="<?php echo e(url('shop')); ?>">Shop <span ></span></a> </li>  
            <?php if( !Session::has('user_id') ): ?>
            <li> <a href="<?php echo e(url('user/signin')); ?>">Login <span ></span></a> </li>
            <li><a href="<?php echo e(url('user/signup')); ?>">SignUp <span ></span></a></li>
            <?php else: ?>
            <li><a href="<?php echo e(url('user/profile')); ?>"><?php echo e(Session::get('user_name')); ?></a></li>
            <?php if( Session::has('is_admin') ): ?>
            <li><a href="<?php echo e(url('cms/dashboard')); ?>" >CMS Dashboard</a></li>
            <?php endif; ?>
            <li><a href="<?php echo e(url('user/logout')); ?>" >Logout</a></li>
            <?php endif; ?>
          </ul>
        </div>

        <div class="collapse navbar-collapse pull-right search-shop-dropdown" id="nav-navbar-collapse-2">
          <ul class="nav navbar-nav navbar-right margin-right-0">
            <li class="dropdown search-dropdown hidden-xs hidden-sm">
              <a href="#" class="" data-toggle="modal" data-target=".header-search"><i class="fa fa-search"></i></a>
            </li>
            <li class="dropdown shop-cart-dropdown">
                <a href="#"  class="dropdown-toggle hidden-xs hidden-sm" data-hover="dropdown" data-toggle="" role="button" aria-haspopup="true" aria-expanded="false"> 
                  <i class="fa fa-shopping-bag"></i> 
                  <?php if( !Cart::isEmpty() ): ?>
                  <div class='badge total-cart'><?php echo e(Cart::getTotalQuantity()); ?></div>
                  <?php endif; ?>
                </a>
            <ul class="dropdown-menu">
               <li class="list-img">
               <ul class="list-ul">
                        <li>
                          <div class="row text-weight-700">
                            <div class="col-xs-8">item(s)</div>
                            <div class="col-xs-4 text-right">$<?php echo e(Cart::getTotal()); ?></div>
                          </div>
                        </li>
       <?php $__currentLoopData = Cart::getContent()->toArray(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <li class="alert">
                          <div class="close"><a href="#" data-dismiss="alert" aria-hidden="false"><i class="fa fa-close"></i></a></div>
                        <div class="list-img"> <a href="#"><img src="<?php echo e(asset('images/'.$product['attributes']['image'] )); ?>" alt="<?php echo e($product['name']); ?>"></a> </div>
                          <div class="list-text">
                           <h5 class="list-title text-weight-600"><a href="#"><?php echo e(ucfirst($product['name'] )); ?></a></h5>
                            <ul class="list-meta list-inline">
                       <li><i class="fa fa-usd"></i> <?php echo e($product['price']); ?></li>
                              <li>
                                <div class="star-rating" data-toggle="tooltip" data-placement="top" title="5.00"> <span class="width-100"><strong class="rating">5.00</strong> out of 5</span> </div>
                              </li>
                            </ul>
                          </div>
                        </li>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                      </ul>
               </li>
               <li class="shop-cart-btn">
                 <div class="btn-group btn-group-justified"> 
                        <a href="<?php echo e(url('shop/checkout')); ?>" class="btn btn-base btn-sm text-weight-700 text-spacing-2 text-uppercase">View Cart</a>
                        <a href="<?php echo e(url('shop/order')); ?>" class="btn btn-dark btn-sm text-weight-700  text-spacing-2 text-uppercase">Checkout</a> </div>
               </li>
             </ul>
                       
              </li>
          </ul>
        </div>
      </div>
      </div>
  </nav>
</header>




