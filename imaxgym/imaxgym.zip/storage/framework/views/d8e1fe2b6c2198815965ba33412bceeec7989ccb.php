<?php $__env->startSection('cms_content'); ?>
<h1 class="page-header">Edit this product</h1>

<br><br>
<div class="row">
  <div class="col-md-6">
     <form  action='<?php echo e(url('cms/products/'. $product['id'])); ?>' method="POST" enctype="multipart/form-data">
      <?php echo e(csrf_field()); ?>

      <?php echo e(method_field('PUT')); ?>

      
      <input type="hidden" name="item_id" value=" <?php echo e($product['id']); ?>">
     <div class="form-group">
        <label for="categorie-id">Category</label>
        <select name='categorie_id' id='categorie-id' class='form-control'>
          <option value='' >Choose Category..</option>
          <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option <?php if($product['categorie_id'] == $category['id'] ): ?>  selected="selected" <?php endif; ?> value='<?php echo e($category['id']); ?>'><?php echo e($category['title']); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
      
    <div class="form-group">
        <label for="title">Title</label>
        <input name='title' value='<?php echo e($product['title']); ?>' type="text" class="form-control origin-text" id="title"  placeholder="title">
        <!--<span class="text-danger"><?php echo e($errors->first('email')); ?></span>-->
    </div>
      
     <div class="form-group">
         <label for="url">Url</label>
         <input name='url' value='<?php echo e($product['url']); ?>' type="text" class="form-control target-text" id="url"  placeholder="url">
        <!--<span class="text-danger"><?php echo e($errors->first('email')); ?></span>-->
     </div>
      
     <div class="form-group">
            <label for="article">Article</label>
           <textarea id="article" name='article' class="form-control"><?php echo e($product['article']); ?></textarea>
        <!--<span class="text-danger"><?php echo e($errors->first('email')); ?></span>-->
    </div>
      
       <div class="form-group">
          <label for="price">Price</label>
          <input id="price" name='price' class="form-control" value ="<?php echo e($product['price']); ?>" class="form-control" id="price" placeholder="price"></input>
        <!--<span class="text-danger"><?php echo e($errors->first('email')); ?></span>-->
      </div>
  
        <div class="form-group">
            <img width='50' src='<?php echo e(asset('images/'. $product['image'])); ?>'><br><br>
           <label for="image"> Change product image</label>
           <input type='file' name='image' id='image'>
       </div>    
      
       <div class="form-group">
          <label for="stock">Stock</label>
          <input id="stock" name='stock' class="form-control" value ="<?php echo e(old('stock')); ?>" class="form-control" id="stock" placeholder="stock"></input>
       </div>
    
       <div class="form-group">
          <label for="rating">Rating</label>
          <input id="rating" name='rating' class="form-control" value ="<?php echo e(old('rating')); ?>" class="form-control" id="stock" placeholder="rating"></input>
       </div>
      
      <a href= "<?php echo e(url('cms/products')); ?>" class="btn btn-default">Cancel</a>
      <input class='btn btn-primary' type='submit' name='submit' value='Save'>
    </form>

  </div>
  
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('cms.cms_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>