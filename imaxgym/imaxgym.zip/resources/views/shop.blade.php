@extends('master')
@section('main_content')
<div class="row">
  <div class="col-md-12">
    <h1>{{str_replace('iMAXGYM | ','',$title)}}</h1>
    
  </div>
</div>
