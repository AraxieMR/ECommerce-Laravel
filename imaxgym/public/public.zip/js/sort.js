var myApp = angular.module("myModule", []);

myApp.controller("myController", function($scope){
  console.log('&&&&&&&&&&&&&&&&&&&&&&&&&');
 
});
    
